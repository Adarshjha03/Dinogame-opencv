install mediapipe in cmd :
pip install mediapipe

install opencv in cmd :
pip install opencv


after running press q to close the camera window
